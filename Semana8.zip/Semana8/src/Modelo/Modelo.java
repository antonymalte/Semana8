
package Modelo;

import javax.swing.JOptionPane;




public class Modelo {
    
   
    private String empleado;
    private String fecha;
    private int i=0,n=-1,j;
    private String combo;
    private String servicio;
    private String total;
    private String[] datos=new String[200];

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public String getEmpleado() {
        return empleado;
    }

    public void setEmpleado(String empleado) {
        this.empleado = empleado;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int getJ() {
        return j;
    }

    public void setJ(int j) {
        this.j = j;
    }

    public String getCombo() {
        return combo;
    }

    public void setCombo(String combo) {
        this.combo = combo;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String[] getDatos() {
        return datos;
    }

    public void setDatos(String[] datos) {
        this.datos = datos;
    }
    public String ingresarServicio(Boolean che5,Boolean che6,Boolean che7,Boolean che8){
        
        if (che5==true && che6==true && che7==true && che8==true )
        {
           servicio="";
             JOptionPane.showMessageDialog(null, "Seleccionar un solo servicio");         
            }
        
        if (che5==true && che6==true && che7==true  )
        {
           servicio="";
             JOptionPane.showMessageDialog(null, "Seleccionar un solo servicio");         
            }
       if (che5==true && che6==true   )
        {
           servicio="";
             JOptionPane.showMessageDialog(null, "Seleccionar un solo servicio");         
            }
        else{
            
        
        if (che5==true)
        {
            servicio=" Lavado Basico ";
        }
       if (che6==true)
       {
            servicio="Lavado Especial";
       }    
       if (che7==true)
       {
            servicio="Desinfeccion Basica "; 
       }
       if (che8==true)
       {
            servicio="Desinfeccion avanzada"; 
       }    
            
        }       
       
        
        
        
        
        return servicio;
        
        
    }
   

   
    public  String ingresarCombo(Boolean che1,Boolean che2,Boolean che3) {
    
        if (che1==true && che2==true && che3==true )
        {
           combo="";
             JOptionPane.showMessageDialog(null, "Seleccionar un solo combo");         
            }
       
        if (che1==true && che2==true  )
            {
           combo="";
             JOptionPane.showMessageDialog(null, "Seleccionar un solo combo");         
            }
   
        if (che1==true)
        {
            combo=" Lavado, polichado y desengrasante por debajo ";
        }
       if (che2==true)
       {
            combo="Combo 1 + grafitado de chasis ";
       }   
       if (che3==true)
       {
            combo="Combo 2 + tapicería (desmontado de sillas para un aseo más profundo) "; 
       } 
            
       
          return combo;
    }

     
    public  String ingresarEmpleado(String nombre) {
        
        return this.empleado=nombre+"      ";
        
    }
      
    public  String ingresarFecha(String fecha) {
        
        return this.fecha =fecha+"         ";
        
    }
    public  String guardarDatos() {
        
      int j=i+1;
      setN(++n);
      while(i < datos.length&& j>i){
          if(getN()==i){
              datos[i]="Servicio:"+getServicio()+"Combo:"+getCombo()+"Empleado:"+getEmpleado()+"Fecha:"+getFecha();
              total=total+"\n"+datos[i];
              ++i;
          }
          else{
              j=0;
          }
      }
    setTotal(total);
       
     return total;
   }

  
    }

    

   

   

        
        