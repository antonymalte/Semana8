
package Controlador;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Modelo.Modelo;
import Vista.Vista;
import javax.swing.JFrame;
import javax.swing.JOptionPane;




public  class Controlador implements ActionListener{
    
    private Modelo modelo;
    private Vista vista;
    private Double cantidad;
    public Controlador(Modelo modelo, Vista vista) {
    this.modelo = modelo;
    this.vista = vista;
    this.vista.jButton1.addActionListener(this);
    this.vista.jButton2.addActionListener(this);

}



public Controlador() {

}







public void iniciarVista() {

vista.pack();
vista.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
vista.setLocationRelativeTo(null);
vista.setVisible(true);
}
/*public ActionEvent Detectar(){
ActionEvent evento;
evento = new ActionEvent(insVista());
return evento;
}*/



public Vista getVista() {
return vista;
}



public void setVista(Vista vista) {
this.vista = vista;
}



@Override
public void actionPerformed(ActionEvent evento) {

if(vista.jButton1==evento.getSource()){
    modelo.ingresarServicio(vista.jCheckBox5.isSelected(),vista.jCheckBox6.isSelected(),vista.jCheckBox7.isSelected(),vista.jCheckBox8.isSelected());
    modelo.ingresarCombo(vista.jCheckBox1.isSelected(), vista.jCheckBox2.isSelected(), vista.jCheckBox3.isSelected());
    modelo.ingresarEmpleado(vista.jTextField2.getText());
    modelo.ingresarFecha(vista.jTextField3.getText());
    modelo.guardarDatos();
    vista.jTextArea1.setText(modelo.getTotal());

}



if(vista.jButton2==evento.getSource()){
System.exit(0);
}



   
    
    
    
   
 
    
    
    
}
}